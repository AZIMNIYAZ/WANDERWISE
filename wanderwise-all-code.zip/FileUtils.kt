package com.example.wanderwise

import android.content.Context
import com.example.wanderwise.db.AppDatabase
import com.example.wanderwise.db.TravelPlaceEntity
import java.io.BufferedReader
import java.io.InputStreamReader

object FileUtils {

    // This function will only parse and save the CSV into the database if it’s empty
    suspend fun parseCsvAndSaveToDatabase(context: Context, db: AppDatabase) {
        val dao = db.travelPlaceDao()

        // Check if database already has entries to avoid re-adding
        if (dao.getAnyPlace() != null) return

        val travelPlaces = mutableListOf<TravelPlaceEntity>()

        try {
            val inputStream = context.assets.open("places to visit.csv")
            val reader = BufferedReader(InputStreamReader(inputStream))

            reader.readLine() // skip header

            reader.forEachLine { line ->
                val tokens = line.split(",")
                if (tokens.size >= 20) {
                    val city = tokens[3].trim()
                    val place = TravelPlaceEntity(
                        city = city,
                        name = tokens[4].trim(),
                        rating = tokens[8].trim().toDoubleOrNull() ?: 0.0,
                        entryFee = tokens[9].trim().toIntOrNull() ?: 0,
                        bestTimeToVisit = tokens[15].trim(),
                        timeNeeded = tokens[7].trim().toDoubleOrNull() ?: 0.0,
                        weeklyOff = tokens[11].trim(),
                        foodExpense = tokens[19].trim().toIntOrNull() ?: 0
                    )
                    travelPlaces.add(place)
                }
            }
            reader.close()
            dao.insertPlaces(travelPlaces)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
