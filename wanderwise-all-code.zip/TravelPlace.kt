package com.example.wanderwise

data class TravelPlace(
    val name: String,
    val rating: Double,
    val entryFee: Int,
    val bestTimeToVisit: String,
    val timeNeeded: Double,
    val weeklyOff: String,
    val foodExpense: Int // ✅ Added food expense field
)
