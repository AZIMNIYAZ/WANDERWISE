package com.example.wanderwise.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "travel_places")
data class TravelPlaceEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val city: String,
    val name: String,
    val rating: Double,
    val entryFee: Int,
    val bestTimeToVisit: String,
    val timeNeeded: Double,
    val weeklyOff: String,
    val foodExpense: Int
)
