package com.example.wanderwise.db;

import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.CoroutinesRoom;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import java.lang.Class;
import java.lang.Exception;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.processing.Generated;
import kotlin.Unit;
import kotlin.coroutines.Continuation;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class TravelPlaceDao_Impl implements TravelPlaceDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<TravelPlaceEntity> __insertionAdapterOfTravelPlaceEntity;

  public TravelPlaceDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfTravelPlaceEntity = new EntityInsertionAdapter<TravelPlaceEntity>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `travel_places` (`id`,`city`,`name`,`rating`,`entryFee`,`bestTimeToVisit`,`timeNeeded`,`weeklyOff`,`foodExpense`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final TravelPlaceEntity entity) {
        statement.bindLong(1, entity.getId());
        if (entity.getCity() == null) {
          statement.bindNull(2);
        } else {
          statement.bindString(2, entity.getCity());
        }
        if (entity.getName() == null) {
          statement.bindNull(3);
        } else {
          statement.bindString(3, entity.getName());
        }
        statement.bindDouble(4, entity.getRating());
        statement.bindLong(5, entity.getEntryFee());
        if (entity.getBestTimeToVisit() == null) {
          statement.bindNull(6);
        } else {
          statement.bindString(6, entity.getBestTimeToVisit());
        }
        statement.bindDouble(7, entity.getTimeNeeded());
        if (entity.getWeeklyOff() == null) {
          statement.bindNull(8);
        } else {
          statement.bindString(8, entity.getWeeklyOff());
        }
        statement.bindLong(9, entity.getFoodExpense());
      }
    };
  }

  @Override
  public Object insertPlaces(final List<TravelPlaceEntity> places,
      final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __insertionAdapterOfTravelPlaceEntity.insert(places);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object getPlacesByCity(final String city,
      final Continuation<? super List<TravelPlaceEntity>> $completion) {
    final String _sql = "SELECT * FROM travel_places WHERE city = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    if (city == null) {
      _statement.bindNull(_argIndex);
    } else {
      _statement.bindString(_argIndex, city);
    }
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<List<TravelPlaceEntity>>() {
      @Override
      @NonNull
      public List<TravelPlaceEntity> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfCity = CursorUtil.getColumnIndexOrThrow(_cursor, "city");
          final int _cursorIndexOfName = CursorUtil.getColumnIndexOrThrow(_cursor, "name");
          final int _cursorIndexOfRating = CursorUtil.getColumnIndexOrThrow(_cursor, "rating");
          final int _cursorIndexOfEntryFee = CursorUtil.getColumnIndexOrThrow(_cursor, "entryFee");
          final int _cursorIndexOfBestTimeToVisit = CursorUtil.getColumnIndexOrThrow(_cursor, "bestTimeToVisit");
          final int _cursorIndexOfTimeNeeded = CursorUtil.getColumnIndexOrThrow(_cursor, "timeNeeded");
          final int _cursorIndexOfWeeklyOff = CursorUtil.getColumnIndexOrThrow(_cursor, "weeklyOff");
          final int _cursorIndexOfFoodExpense = CursorUtil.getColumnIndexOrThrow(_cursor, "foodExpense");
          final List<TravelPlaceEntity> _result = new ArrayList<TravelPlaceEntity>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final TravelPlaceEntity _item;
            final int _tmpId;
            _tmpId = _cursor.getInt(_cursorIndexOfId);
            final String _tmpCity;
            if (_cursor.isNull(_cursorIndexOfCity)) {
              _tmpCity = null;
            } else {
              _tmpCity = _cursor.getString(_cursorIndexOfCity);
            }
            final String _tmpName;
            if (_cursor.isNull(_cursorIndexOfName)) {
              _tmpName = null;
            } else {
              _tmpName = _cursor.getString(_cursorIndexOfName);
            }
            final double _tmpRating;
            _tmpRating = _cursor.getDouble(_cursorIndexOfRating);
            final int _tmpEntryFee;
            _tmpEntryFee = _cursor.getInt(_cursorIndexOfEntryFee);
            final String _tmpBestTimeToVisit;
            if (_cursor.isNull(_cursorIndexOfBestTimeToVisit)) {
              _tmpBestTimeToVisit = null;
            } else {
              _tmpBestTimeToVisit = _cursor.getString(_cursorIndexOfBestTimeToVisit);
            }
            final double _tmpTimeNeeded;
            _tmpTimeNeeded = _cursor.getDouble(_cursorIndexOfTimeNeeded);
            final String _tmpWeeklyOff;
            if (_cursor.isNull(_cursorIndexOfWeeklyOff)) {
              _tmpWeeklyOff = null;
            } else {
              _tmpWeeklyOff = _cursor.getString(_cursorIndexOfWeeklyOff);
            }
            final int _tmpFoodExpense;
            _tmpFoodExpense = _cursor.getInt(_cursorIndexOfFoodExpense);
            _item = new TravelPlaceEntity(_tmpId,_tmpCity,_tmpName,_tmpRating,_tmpEntryFee,_tmpBestTimeToVisit,_tmpTimeNeeded,_tmpWeeklyOff,_tmpFoodExpense);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @Override
  public Object getAllCities(final Continuation<? super List<String>> $completion) {
    final String _sql = "SELECT DISTINCT city FROM travel_places";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<List<String>>() {
      @Override
      @NonNull
      public List<String> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final List<String> _result = new ArrayList<String>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final String _item;
            if (_cursor.isNull(0)) {
              _item = null;
            } else {
              _item = _cursor.getString(0);
            }
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @Override
  public Object getAnyPlace(final Continuation<? super TravelPlaceEntity> $completion) {
    final String _sql = "SELECT * FROM travel_places LIMIT 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<TravelPlaceEntity>() {
      @Override
      @Nullable
      public TravelPlaceEntity call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfId = CursorUtil.getColumnIndexOrThrow(_cursor, "id");
          final int _cursorIndexOfCity = CursorUtil.getColumnIndexOrThrow(_cursor, "city");
          final int _cursorIndexOfName = CursorUtil.getColumnIndexOrThrow(_cursor, "name");
          final int _cursorIndexOfRating = CursorUtil.getColumnIndexOrThrow(_cursor, "rating");
          final int _cursorIndexOfEntryFee = CursorUtil.getColumnIndexOrThrow(_cursor, "entryFee");
          final int _cursorIndexOfBestTimeToVisit = CursorUtil.getColumnIndexOrThrow(_cursor, "bestTimeToVisit");
          final int _cursorIndexOfTimeNeeded = CursorUtil.getColumnIndexOrThrow(_cursor, "timeNeeded");
          final int _cursorIndexOfWeeklyOff = CursorUtil.getColumnIndexOrThrow(_cursor, "weeklyOff");
          final int _cursorIndexOfFoodExpense = CursorUtil.getColumnIndexOrThrow(_cursor, "foodExpense");
          final TravelPlaceEntity _result;
          if (_cursor.moveToFirst()) {
            final int _tmpId;
            _tmpId = _cursor.getInt(_cursorIndexOfId);
            final String _tmpCity;
            if (_cursor.isNull(_cursorIndexOfCity)) {
              _tmpCity = null;
            } else {
              _tmpCity = _cursor.getString(_cursorIndexOfCity);
            }
            final String _tmpName;
            if (_cursor.isNull(_cursorIndexOfName)) {
              _tmpName = null;
            } else {
              _tmpName = _cursor.getString(_cursorIndexOfName);
            }
            final double _tmpRating;
            _tmpRating = _cursor.getDouble(_cursorIndexOfRating);
            final int _tmpEntryFee;
            _tmpEntryFee = _cursor.getInt(_cursorIndexOfEntryFee);
            final String _tmpBestTimeToVisit;
            if (_cursor.isNull(_cursorIndexOfBestTimeToVisit)) {
              _tmpBestTimeToVisit = null;
            } else {
              _tmpBestTimeToVisit = _cursor.getString(_cursorIndexOfBestTimeToVisit);
            }
            final double _tmpTimeNeeded;
            _tmpTimeNeeded = _cursor.getDouble(_cursorIndexOfTimeNeeded);
            final String _tmpWeeklyOff;
            if (_cursor.isNull(_cursorIndexOfWeeklyOff)) {
              _tmpWeeklyOff = null;
            } else {
              _tmpWeeklyOff = _cursor.getString(_cursorIndexOfWeeklyOff);
            }
            final int _tmpFoodExpense;
            _tmpFoodExpense = _cursor.getInt(_cursorIndexOfFoodExpense);
            _result = new TravelPlaceEntity(_tmpId,_tmpCity,_tmpName,_tmpRating,_tmpEntryFee,_tmpBestTimeToVisit,_tmpTimeNeeded,_tmpWeeklyOff,_tmpFoodExpense);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
