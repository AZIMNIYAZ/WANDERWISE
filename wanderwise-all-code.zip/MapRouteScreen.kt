package com.example.wanderwise

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.model.*
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

@Composable
fun MapRouteScreen(destinationCity: String) {
    val context = LocalContext.current
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }
    val mapView = rememberMapViewWithLifecycle()
    var userLocation by remember { mutableStateOf<LatLng?>(null) }
    val locationPermissionGranted = remember { mutableStateOf(false) }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        locationPermissionGranted.value = isGranted
        Log.d("MapRouteScreen", "Location permission granted: $isGranted")
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            locationPermissionGranted.value = true
        } else {
            locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    val destinationLatLng = when (destinationCity.lowercase()) {
        "delhi" -> LatLng(28.6139, 77.2090)
        "goa" -> LatLng(15.2993, 74.1240)
        "ahmedabad" -> LatLng(23.0225, 72.5714)
        else -> LatLng(20.5937, 78.9629)
    }

    LaunchedEffect(locationPermissionGranted.value) {
        if (locationPermissionGranted.value) {
            val location = withContext(Dispatchers.IO) {
                suspendCancellableCoroutine { cont ->
                    fusedLocationClient.lastLocation
                        .addOnSuccessListener { cont.resume(it) }
                        .addOnFailureListener { cont.resume(null) }
                }
            }
            userLocation = location?.let { LatLng(it.latitude, it.longitude) }
            Log.d("MapRouteScreen", "User location: $userLocation")
        }
    }

    // 👇 FIXED: Added Modifier with height to make the map visible!
    AndroidView(
        factory = { mapView },
        modifier = Modifier
            .fillMaxWidth()
            .height(400.dp)
    ) { map ->
        map.getMapAsync { googleMap ->
            userLocation?.let { start ->
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(start, 5f))
                googleMap.addMarker(MarkerOptions().position(start).title("You"))
                googleMap.addMarker(MarkerOptions().position(destinationLatLng).title(destinationCity))

                val url =
                    "https://maps.googleapis.com/maps/api/directions/json?" +
                            "origin=${start.latitude},${start.longitude}" +
                            "&destination=${destinationLatLng.latitude},${destinationLatLng.longitude}" +
                            "&key=${context.getString(R.string.google_maps_key)}"

                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val response = OkHttpClient().newCall(Request.Builder().url(url).build()).execute()
                        val json = response.body?.string()
                        val polyline = JSONObject(json)
                            .getJSONArray("routes")
                            .getJSONObject(0)
                            .getJSONObject("overview_polyline")
                            .getString("points")

                        val points = decodePolyline(polyline)

                        withContext(Dispatchers.Main) {
                            googleMap.addPolyline(
                                PolylineOptions()
                                    .addAll(points)
                                    .width(8f)
                                    .color(Color.Blue.toArgb())
                            )
                        }
                    } catch (e: Exception) {
                        Log.e("MapRouteScreen", "Failed to fetch route: ${e.message}")
                    }
                }
            }
        }
    }
}

fun decodePolyline(encoded: String): List<LatLng> {
    val poly = ArrayList<LatLng>()
    var index = 0
    val len = encoded.length
    var lat = 0
    var lng = 0

    while (index < len) {
        var b: Int
        var shift = 0
        var result = 0

        do {
            b = encoded[index++].code - 63
            result = result or ((b and 0x1f) shl shift)
            shift += 5
        } while (b >= 0x20)

        val dlat = if ((result and 1) != 0) (result shr 1).inv() else (result shr 1)
        lat += dlat

        shift = 0
        result = 0

        do {
            b = encoded[index++].code - 63
            result = result or ((b and 0x1f) shl shift)
            shift += 5
        } while (b >= 0x20)

        val dlng = if ((result and 1) != 0) (result shr 1).inv() else (result shr 1)
        lng += dlng

        val p = LatLng(lat / 1E5, lng / 1E5)
        poly.add(p)
    }

    return poly
}

@Composable
fun rememberMapViewWithLifecycle(): MapView {
    val context = LocalContext.current
    val mapView = remember { MapView(context) }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_CREATE -> mapView.onCreate(Bundle())
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> mapView.onDestroy()
                else -> {}
            }
        }

        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    return mapView
}
