package com.example.wanderwise.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface TravelPlaceDao {

    @Query("SELECT * FROM travel_places WHERE city = :city")
    suspend fun getPlacesByCity(city: String): List<TravelPlaceEntity>

    @Query("SELECT DISTINCT city FROM travel_places")
    suspend fun getAllCities(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaces(places: List<TravelPlaceEntity>) // ✅ Renamed for clarity

    @Query("SELECT * FROM travel_places LIMIT 1")
    suspend fun getAnyPlace(): TravelPlaceEntity? // ✅ Helper function to check if DB has data
}
