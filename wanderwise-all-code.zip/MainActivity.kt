package com.example.wanderwise

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import com.example.wanderwise.db.AppDatabase
import com.example.wanderwise.db.TravelPlaceEntity
import com.example.wanderwise.ui.theme.WanderWiseTheme
import com.example.wanderwise.MapRouteScreen


class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            WanderWiseTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    MainScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }

    // ✅ Step 1: Request location permission at runtime
    override fun onStart() {
        super.onStart()
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
            1
        )
    }
}

@Composable
fun MainScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val db = remember { AppDatabase.getDatabase(context) }

    var cityList by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedCity by remember { mutableStateOf("Delhi") }
    var travelPlaces by remember { mutableStateOf<List<TravelPlaceEntity>>(emptyList()) }
    var totalCost by remember { mutableStateOf(0) }

    // Load DB and parse CSV only once
    LaunchedEffect(Unit) {
        FileUtils.parseCsvAndSaveToDatabase(context, db)
        cityList = db.travelPlaceDao().getAllCities()
        if (cityList.isNotEmpty()) selectedCity = cityList.first()
    }

    // Load places whenever the selected city changes
    LaunchedEffect(selectedCity) {
        travelPlaces = db.travelPlaceDao().getPlacesByCity(selectedCity)
        totalCost = travelPlaces.sumOf { it.entryFee + it.foodExpense }
    }

    Column(modifier = modifier.padding(16.dp)) {
        CityDropdown(cityList, selectedCity) { selectedCity = it }
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "Places to Visit in $selectedCity", style = MaterialTheme.typography.headlineMedium)
        TravelPlacesList(places = travelPlaces, totalCost, selectedCity)

        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "Route to $selectedCity", style = MaterialTheme.typography.headlineMedium)

        // ✅ Step 2: Show the route map
        MapRouteScreen(destinationCity = selectedCity)
    }
}

@Composable
fun CityDropdown(cityList: List<String>, selectedCity: String, onCitySelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        OutlinedButton(onClick = { expanded = true }) {
            Text(selectedCity)
        }

        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            cityList.forEach { city ->
                DropdownMenuItem(
                    text = { Text(city) },
                    onClick = {
                        onCitySelected(city)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun TravelPlacesList(places: List<TravelPlaceEntity>, totalCost: Int, selectedCity: String, modifier: Modifier = Modifier) {
    LazyColumn(modifier = modifier.padding(16.dp)) {
        items(places) { place ->
            TravelPlaceItem(place)
        }
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Overall Cost: ₹$totalCost",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Your estimated cost for visiting places in $selectedCity is ₹$totalCost (including food expenses). Enjoy your trip! ✈️",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        }
    }
}

@Composable
fun TravelPlaceItem(place: TravelPlaceEntity) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = place.name, style = MaterialTheme.typography.headlineSmall)
            Text(text = "Rating: ${place.rating}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Entry Fee: ₹${place.entryFee}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Food Expense: ₹${place.foodExpense}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Best Time to Visit: ${place.bestTimeToVisit}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Time Needed: ${place.timeNeeded} hrs", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Weekly Off: ${place.weeklyOff}", style = MaterialTheme.typography.bodyMedium)
        }
    }
}
